# main.py
from services.auth_service import authenticate_user


def main():
    print("🌳 林草资源智能监测系统")
    print("-" * 30)

    while True:
        username = input("👤 用户名: ").strip()
        password = input("🔑 密 码: ").strip()

        if not username or not password:
            print("❌ 用户名和密码不能为空！")
            continue

        user = authenticate_user(username, password)
        if user:
            print(f"\n✅ 登录成功！欢迎 {user['real_name']} ({user['role']})")
            role = user["role"]
            if role == "ranger":
                ranger_main(user)
            elif role == "admin":
                admin_main(user)
            elif role == "supervisor":
                supervisor_main(user)
            elif role == "data_admin":
                data_admin_main(user)
            else:
                general_main(user)
        else:
            print("❌ 用户名或密码错误！")


# --- 角色主函数 ---
def ranger_main(user):
    while True:
        print(f"\n【区域护林员工作台 - {user['real_name']}】")
        print("1. 查看负责区域监测数据")
        print("2. 处理待办灾害预警")
        print("3. 记录设备维护情况")
        print("4. 提交资源变动申请")
        print("0. 退出登录")
        choice = input("请选择: ").strip()

        if choice == "0":
            break
        elif choice == "1":
            from services.monitoring_service import get_regions_by_ranger, get_monitoring_data_by_region
            regions = get_regions_by_ranger(user["user_id"])
            if not regions:
                print("⚠️ 你当前未负责任何区域。")
                continue
            print("\n📋 你负责的区域：")
            for r in regions:
                print(f" - {r['region_name']} ({r['region_type']}) [ID: {r['region_id']}]")
            region_id = input("\n请输入要查询的区域ID: ").strip()
            if not region_id:
                print("❌ 区域ID不能为空")
                continue
            # 检查权限
            if region_id not in [r['region_id'] for r in regions]:
                print("❌ 无权访问该区域！")
                continue
            data = get_monitoring_data_by_region(region_id, hours=24)
            if not data:
                print("🔍 该区域最近24小时无有效监测数据。")
            else:
                print(f"\n📊 {region_id} 最近24小时监测数据（共{len(data)}条）：")
                print("设备名称\t类型\t采集时间\t\t数值\t状态")
                for row in data:
                    value = row['value_number'] if row['value_number'] is not None else row['value_text']
                    print(
                        f"{row['device_name']}\t{row['monitor_type']}\t{row['collect_time']}\t{value}\t{row['data_status']}")
        elif choice == "2":
            from services.alert_service import view_and_handle_alerts
            view_and_handle_alerts(user)
        elif choice == "3":
            from services.maintenance_service import record_maintenance
            record_maintenance(user)
        elif choice == "4":
            from services.resource_service import submit_resource_change_request  # 注意：改名更准确
            submit_resource_change_request(user)
        else:
            print("❓ 无效选项")

def admin_main(user):
    """系统管理员主菜单"""
    while True:
        print(f"\n【系统管理员工作台 - {user['real_name']}】")
        print("1. 用户账号管理")
        print("2. 区域分配管理")
        print("3. 设备档案管理")
        print("0. 退出登录")
        choice = input("请选择: ").strip()

        if choice == "0":
            break
        elif choice == "1":
            from services.admin_service import manage_users
            manage_users()
        elif choice == "2":
            from services.admin_service import manage_region_assignments
            manage_region_assignments()
        elif choice == "3":
            from services.admin_service import manage_devices
            manage_devices()
        else:
            print("❓ 无效选项")


def supervisor_main(user):
    """监管员主菜单"""
    while True:
        print(f"\n【区域监管员工作台 - {user['real_name']}】")
        print("1. 审核资源变动申请")
        print("2. 查看辖区预警汇总")
        print("3. 查阅设备维护日志")
        print("0. 退出登录")
        choice = input("请选择: ").strip()

        if choice == "0":
            break
        elif choice == "1":
            from services.change_service import review_resource_changes
            review_resource_changes(user)
        elif choice == "2":
            from services.alert_service import view_alert_summary_for_supervisor
            view_alert_summary_for_supervisor(user)
        elif choice == "3":
            from services.maintenance_service import view_maintenance_logs_for_supervisor
            view_maintenance_logs_for_supervisor(user)
        else:
            print("❓ 无效选项")

def data_admin_main(user):
    while True:
        print(f"\n【数据管理员工作台 - {user['real_name']}】")
        print("1. 查看全区资源汇总")
        print("2. 按区域统计资源分布")
        print("3. 导出变动日志（CSV）")
        print("0. 退出登录")
        choice = input("请选择: ").strip()

        if choice == "0":
            break
        elif choice == "1":
            from services.report_service import view_resource_summary
            view_resource_summary()
        elif choice == "2":
            from services.report_service import view_resource_by_region
            view_resource_by_region()
        elif choice == "3":
            from services.report_service import export_change_logs
            export_change_logs()
        else:
            print("❓ 无效选项")


def general_main(user):
    print("📄 其他角色功能暂未开放。")



if __name__ == "__main__":
    main()