# utils/security.py
import hashlib

def hash_password(password: str) -> str:
    """生成 SHA256 哈希（与 MySQL SHA2(password, 256) 兼容）"""
    return hashlib.sha256(password.encode('utf-8')).hexdigest()

def verify_password(plain_password: str, hashed_password: str) -> bool:
    """验证明文密码是否与 SHA256 哈希匹配"""
    return hash_password(plain_password) == hashed_password