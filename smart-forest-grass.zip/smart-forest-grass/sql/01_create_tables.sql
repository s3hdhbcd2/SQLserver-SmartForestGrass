-- sql/01_create_tables.sql
SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- 用户表（系统管理员、数据管理员、区域护林员、监管人员）
CREATE TABLE user (
    user_id CHAR(36) PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password_hash VARCHAR(100) NOT NULL,
    real_name VARCHAR(50) NOT NULL,
    role ENUM('admin', 'data_admin', 'ranger', 'supervisor', 'public') NOT NULL, -- 增加公众用户角色
    phone VARCHAR(20),
    email VARCHAR(100),
    is_active TINYINT DEFAULT 1,
    create_time DATETIME DEFAULT CURRENT_TIMESTAMP,
    is_deleted TINYINT DEFAULT 0
);

-- 区域信息表
CREATE TABLE region (
    region_id CHAR(36) PRIMARY KEY,
    region_name VARCHAR(100) NOT NULL,
    region_type ENUM('forest', 'grassland') NOT NULL,
    latitude DECIMAL(10, 6),
    longitude DECIMAL(10, 6),
    ranger_id CHAR(36),  -- 关联护林员
    create_time DATETIME DEFAULT CURRENT_TIMESTAMP,
    is_deleted TINYINT DEFAULT 0,
    INDEX idx_ranger_id (ranger_id)
);

-- 设备档案表
CREATE TABLE device (
    device_id CHAR(36) PRIMARY KEY,
    device_name VARCHAR(100) NOT NULL,
    device_type ENUM('sensor', 'camera', 'alert_device') NOT NULL,
    model VARCHAR(50),
    monitor_type ENUM('temperature', 'humidity', 'image', 'other') NOT NULL,
    region_id CHAR(36) NOT NULL,
    install_time DATETIME,
    protocol VARCHAR(20),
    purchase_time DATE,
    warranty_months INT,
    installer_id CHAR(36),
    create_time DATETIME DEFAULT CURRENT_TIMESTAMP,
    is_deleted TINYINT DEFAULT 0,
    FOREIGN KEY (region_id) REFERENCES region(region_id) ON DELETE CASCADE,
    FOREIGN KEY (installer_id) REFERENCES user(user_id) ON DELETE SET NULL
);

-- 实时监测数据表
CREATE TABLE monitoring_data (
    data_id CHAR(36) PRIMARY KEY,
    device_id CHAR(36) NOT NULL,
    collect_time DATETIME NOT NULL,
    value_number DECIMAL(10,2),
    value_text VARCHAR(255),
    data_status ENUM('valid', 'invalid') NOT NULL,
    create_time DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (device_id) REFERENCES device(device_id) ON DELETE CASCADE,
    INDEX idx_collect_time (collect_time)
);

-- 预警规则表
CREATE TABLE alert_rule (
    rule_id CHAR(36) PRIMARY KEY,
    rule_name VARCHAR(100) NOT NULL,
    alert_type ENUM('fire', 'drought', 'pest', 'other') NOT NULL,
    condition_desc VARCHAR(255) NOT NULL,
    alert_level ENUM('normal', 'moderate', 'severe', 'extreme') NOT NULL,
    is_enabled TINYINT DEFAULT 1,
    create_time DATETIME DEFAULT CURRENT_TIMESTAMP,
    is_deleted TINYINT DEFAULT 0
);

-- 预警记录表
CREATE TABLE alert_record (
    alert_id CHAR(36) PRIMARY KEY,
    rule_id CHAR(36) NOT NULL,
    region_id CHAR(36) NOT NULL,
    trigger_time DATETIME NOT NULL,
    content TEXT NOT NULL,
    status ENUM('unhandled', 'handling', 'resolved') NOT NULL,
    handler_id CHAR(36),
    handle_result TEXT,
    create_time DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (rule_id) REFERENCES alert_rule(rule_id) ON DELETE CASCADE,
    FOREIGN KEY (region_id) REFERENCES region(region_id) ON DELETE CASCADE,
    FOREIGN KEY (handler_id) REFERENCES user(user_id) ON DELETE SET NULL
);

-- 林草资源信息表
CREATE TABLE resource (
    resource_id CHAR(36) PRIMARY KEY,
    resource_type ENUM('tree', 'grass') NOT NULL,
    region_id CHAR(36) NOT NULL,
    species_name VARCHAR(100),
    quantity DECIMAL(12,2),
    area DECIMAL(12,2),
    growth_stage ENUM('seedling', 'growth', 'mature') NOT NULL,
    plant_time DATE,
    update_time DATETIME,
    create_time DATETIME DEFAULT CURRENT_TIMESTAMP,
    is_deleted TINYINT DEFAULT 0,
    FOREIGN KEY (region_id) REFERENCES region(region_id) ON DELETE CASCADE
);

-- 资源变动记录表
CREATE TABLE resource_change_log (
    change_id CHAR(36) PRIMARY KEY,
    resource_id CHAR(36) NOT NULL,
    change_type ENUM('add', 'reduce', 'update') NOT NULL,
    change_reason VARCHAR(255),
    change_time DATETIME NOT NULL,
    operator_id CHAR(36) NOT NULL,
    create_time DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (resource_id) REFERENCES resource(resource_id) ON DELETE CASCADE,
    FOREIGN KEY (operator_id) REFERENCES user(user_id) ON DELETE CASCADE
);

-- 维护记录表
CREATE TABLE maintenance_log (
    log_id CHAR(36) PRIMARY KEY,
    device_id CHAR(36) NOT NULL,
    maintainer_id CHAR(36) NOT NULL,  -- 护林员 user_id
    maintenance_time DATETIME NOT NULL,
    content TEXT NOT NULL,
    result VARCHAR(50),               -- 如 "正常" / "已更换"
    create_time DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (device_id) REFERENCES device(device_id) ON DELETE CASCADE,
    FOREIGN KEY (maintainer_id) REFERENCES user(user_id) ON DELETE CASCADE
);

-- 统计报表模板表
CREATE TABLE report_template (
    template_id CHAR(36) PRIMARY KEY,
    template_name VARCHAR(100) NOT NULL,
    dimensions VARCHAR(255) NOT NULL,  -- 统计维度
    indicators VARCHAR(255) NOT NULL,  -- 统计指标
    generate_cycle ENUM('daily', 'weekly', 'monthly') NOT NULL,
    create_time DATETIME DEFAULT CURRENT_TIMESTAMP,
    is_deleted TINYINT DEFAULT 0
);

-- 生成报表数据表
CREATE TABLE generated_report (
    report_id CHAR(36) PRIMARY KEY,
    template_id CHAR(36) NOT NULL,
    cycle_start DATETIME NOT NULL,
    cycle_end DATETIME NOT NULL,
    generate_time DATETIME DEFAULT CURRENT_TIMESTAMP,
    file_path VARCHAR(255),
    FOREIGN KEY (template_id) REFERENCES report_template(template_id) ON DELETE CASCADE
);

-- 通知记录表
CREATE TABLE notification (
    notification_id CHAR(36) PRIMARY KEY,
    alert_id CHAR(36) NOT NULL,
    recipient_id CHAR(36) NOT NULL,
    method ENUM('sms', 'system_message') NOT NULL,
    send_time DATETIME NOT NULL,
    receive_status ENUM('pending', 'received', 'failed') NOT NULL,
    FOREIGN KEY (alert_id) REFERENCES alert_record(alert_id) ON DELETE CASCADE,
    FOREIGN KEY (recipient_id) REFERENCES user(user_id) ON DELETE CASCADE
);

-- 资源变动申请表（待监管员审核）
CREATE TABLE resource_change_request (
    request_id CHAR(36) PRIMARY KEY,
    resource_id CHAR(36) NOT NULL,
    change_type ENUM('add', 'reduce', 'update') NOT NULL,
    amount DECIMAL(12,2),           -- 用于 add/reduce
    new_growth_stage ENUM('seedling', 'growth', 'mature'), -- 用于 update
    reason TEXT NOT NULL,
    requester_id CHAR(36) NOT NULL,
    status ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
    approver_id CHAR(36),
    approve_time DATETIME,
    create_time DATETIME DEFAULT CURRENT_TIMESTAMP,
    is_deleted TINYINT DEFAULT 0,
    FOREIGN KEY (resource_id) REFERENCES resource(resource_id) ON DELETE CASCADE,
    FOREIGN KEY (requester_id) REFERENCES user(user_id) ON DELETE CASCADE,
    FOREIGN KEY (approver_id) REFERENCES user(user_id) ON DELETE SET NULL
);


SET FOREIGN_KEY_CHECKS = 1;