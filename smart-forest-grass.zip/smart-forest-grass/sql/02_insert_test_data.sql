-- 设置字符集和关闭外键检查（确保插入顺序不影响）
SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ========================
-- 1. 插入用户数据（user）
-- ========================
INSERT INTO user (user_id, username, password_hash, real_name, role, phone, email, is_active)
VALUES
('u-admin-001', 'admin', SHA2('123456', 256), '系统管理员', 'admin', '13800138001', 'admin@smartforest.com', 1),
('u-data-001', 'data_mgr', SHA2('123456', 256), '数据管理员', 'data_admin', '13800138002', 'data@smartforest.com', 1),
('u-ranger-001', 'ranger_north', SHA2('123456', 256), '张护林', 'ranger', '13800138003', 'ranger@smartforest.com', 1),
('u-sup-001', 'supervisor_01', SHA2('123456', 256), '李监管', 'supervisor', '13800138004', 'sup@smartforest.com', 1),
('u-public-001', 'public_user', SHA2('123456', 256), '公众用户', 'public', NULL, 'public@example.com', 1);

-- ========================
-- 2. 插入区域数据（region）
-- ========================
INSERT INTO region (region_id, region_name, region_type, latitude, longitude, ranger_id)
VALUES
('reg-f-001', '北山森林保护区', 'forest', 39.9042, 116.4074, 'u-ranger-001'),
('reg-g-001', '呼伦贝尔草原A区', 'grassland', 49.2136, 117.3584, 'u-ranger-001');

-- ========================
-- 3. 插入设备数据（device）
-- ========================
INSERT INTO device (
    device_id, device_name, device_type, model, monitor_type,
    region_id, install_time, protocol, purchase_time, warranty_months, installer_id
) VALUES
('dev-s-001', '北山温湿度传感器01', 'sensor', 'TH-S200', 'temperature',
 'reg-f-001', '2025-01-10 09:00:00', 'LoRa', '2025-01-05', 24, 'u-admin-001'),

('dev-s-002', '北山湿度传感器02', 'sensor', 'TH-S200', 'humidity',
 'reg-f-001', '2025-01-10 09:05:00', 'LoRa', '2025-01-05', 24, 'u-admin-001'),

('dev-c-001', '草原监控摄像头A1', 'camera', 'CAM-HD900', 'image',
 'reg-g-001', '2025-02-15 10:00:00', '4G', '2025-02-10', 36, 'u-data-001'),

('dev-a-001', '火灾声光报警器F1', 'alert_device', 'ALERT-FIRE1', 'other',
 'reg-f-001', '2025-03-01 14:00:00', 'Zigbee', '2025-02-25', 12, 'u-admin-001');

-- ========================
-- 4. 插入实时监测数据（monitoring_data）
-- ========================
INSERT INTO monitoring_data (data_id, device_id, collect_time, value_number, value_text, data_status)
VALUES
('md-001', 'dev-s-001', '2026-01-01 08:00:00', 23.50, NULL, 'valid'),
('md-002', 'dev-s-001', '2026-01-01 09:00:00', 25.10, NULL, 'valid'),
('md-003', 'dev-s-002', '2026-01-01 08:00:00', 65.30, NULL, 'valid'),
('md-004', 'dev-s-002', '2026-01-01 09:00:00', 60.80, NULL, 'valid'),
('md-005', 'dev-c-001', '2026-01-01 10:00:00', NULL, 'snapshot_202601011000.jpg', 'valid');

-- ========================
-- 5. 插入预警规则（alert_rule）
-- ========================
INSERT INTO alert_rule (rule_id, rule_name, alert_type, condition_desc, alert_level, is_enabled)
VALUES
('rule-fire-01', '高温火灾预警', 'fire', 'temperature > 40℃ 持续30分钟', 'severe', 1),
('rule-drought-01', '持续干旱预警', 'drought', 'humidity < 20% 持续7天', 'moderate', 1),
('rule-pest-01', '虫害图像识别预警', 'pest', 'AI检测到虫害特征', 'extreme', 1);

-- ========================
-- 6. 插入预警记录（alert_record）
-- ========================
INSERT INTO alert_record (
    alert_id, rule_id, region_id, trigger_time, content, status, handler_id
) VALUES
('alert-001', 'rule-fire-01', 'reg-f-001', '2026-01-01 09:30:00',
 '北山区域温度达42.1℃，触发火灾预警', 'unhandled', NULL),

('alert-002', 'rule-drought-01', 'reg-g-001', '2026-01-01 11:00:00',
 '呼伦贝尔草原湿度连续7天低于18%，触发干旱预警', 'handling', 'u-ranger-001');

-- ========================
-- 7. 插入林草资源信息（resource）
-- ========================
INSERT INTO resource (
    resource_id, resource_type, region_id, species_name, quantity, area, growth_stage, plant_time
) VALUES
('res-tree-001', 'tree', 'reg-f-001', '油松', 15000.00, 500.00, 'mature', '2010-04-12'),
('res-grass-001', 'grass', 'reg-g-001', '羊草', 80000.00, 1200.00, 'growth', '2020-05-20');

-- ========================
-- 8. 插入资源变动记录（resource_change_log）
-- ========================
INSERT INTO resource_change_log (
    change_id, resource_id, change_type, change_reason, change_time, operator_id
) VALUES
('chg-001', 'res-tree-001', 'reduce', '病虫害砍伐', '2025-10-15 14:20:00', 'u-ranger-001'),
('chg-002', 'res-grass-001', 'add', '春季补种', '2025-04-10 09:00:00', 'u-ranger-001');

-- ========================
-- 9. 插入设备维护记录（maintenance_log）
-- ========================
INSERT INTO maintenance_log (
    log_id, device_id, maintainer_id, maintenance_time, content, result
) VALUES
('mnt-001', 'dev-s-001', 'u-ranger-001', '2025-12-20 10:30:00',
 '清洁传感器探头，校准温湿度', '正常'),

('mnt-002', 'dev-c-001', 'u-ranger-001', '2026-01-02 15:00:00',
 '更换摄像头电池，检查4G信号', '已更换');

-- ========================
-- 10. 插入报表模板（report_template）
-- ========================
INSERT INTO report_template (template_id, template_name, dimensions, indicators, generate_cycle)
VALUES
('tmpl-001', '月度环境监测汇总', 'region,device_type', 'avg_temperature,avg_humidity', 'monthly'),
('tmpl-002', '季度灾害预警统计', 'alert_type,region', 'alert_count,resolved_rate', 'weekly');

-- ========================
-- 11. 插入生成的报表（generated_report）
-- ========================
INSERT INTO generated_report (report_id, template_id, cycle_start, cycle_end, file_path)
VALUES
('rep-001', 'tmpl-001', '2025-12-01 00:00:00', '2025-12-31 23:59:59', '/reports/202512_env_summary.pdf'),
('rep-002', 'tmpl-002', '2026-01-01 00:00:00', '2026-01-07 23:59:59', '/reports/2026w1_alert_stats.xlsx');

-- ========================
-- 12. 插入通知记录（notification）
-- ========================
INSERT INTO notification (
    notification_id, alert_id, recipient_id, method, send_time, receive_status
) VALUES
('noti-001', 'alert-001', 'u-sup-001', 'sms', '2026-01-01 09:31:00', 'received'),
('noti-002', 'alert-001', 'u-ranger-001', 'system_message', '2026-01-01 09:31:05', 'received');

-- 恢复外键检查
SET FOREIGN_KEY_CHECKS = 1;