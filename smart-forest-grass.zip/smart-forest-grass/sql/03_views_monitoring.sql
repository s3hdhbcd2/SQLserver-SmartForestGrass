-- sql/03_views_monitoring.sql
-- 环境监测业务线专用视图（共3个）
-- 作者：[你的姓名]
-- 功能：支持护林员、数据管理员、监管人员高效查询监测数据

-- 视图1：各区域近7天有效温度日均值（用于趋势分析）
CREATE VIEW v_region_daily_avg_temperature AS
SELECT
    r.region_id,
    r.region_name,
    DATE(m.collect_time) AS collect_date,
    ROUND(AVG(m.value_number), 2) AS avg_temperature
FROM monitoring_data m
JOIN device d ON m.device_id = d.device_id
JOIN region r ON d.region_id = r.region_id
WHERE d.monitor_type = 'temperature'
  AND m.data_status = 'valid'
  AND m.collect_time >= DATE_SUB(NOW(), INTERVAL 7 DAY)
GROUP BY r.region_id, r.region_name, DATE(m.collect_time)
ORDER BY r.region_name, collect_date;

-- 视图2：所有标记为“无效”的监测数据清单（供数据管理员审核）
CREATE VIEW v_invalid_monitoring_records AS
SELECT
    m.data_id,
    r.region_name,
    d.device_name,
    d.monitor_type,
    m.collect_time,
    m.value_number,
    m.value_text,
    m.create_time AS record_create_time
FROM monitoring_data m
JOIN device d ON m.device_id = d.device_id
JOIN region r ON d.region_id = r.region_id
WHERE m.data_status = 'invalid'
ORDER BY m.collect_time DESC;

-- 视图3：各区域传感器部署汇总（含设备类型分布）
CREATE VIEW v_device_deployment_summary AS
SELECT
    r.region_id,
    r.region_name,
    r.region_type,
    COUNT(d.device_id) AS total_devices,
    SUM(CASE WHEN d.device_type = 'sensor' THEN 1 ELSE 0 END) AS sensor_count,
    SUM(CASE WHEN d.device_type = 'camera' THEN 1 ELSE 0 END) AS camera_count,
    SUM(CASE WHEN d.device_type = 'alert_device' THEN 1 ELSE 0 END) AS alert_device_count,
    u.real_name AS ranger_name
FROM region r
LEFT JOIN device d ON r.region_id = d.region_id AND d.is_deleted = 0
LEFT JOIN user u ON r.ranger_id = u.user_id
WHERE r.is_deleted = 0
GROUP BY r.region_id, r.region_name, r.region_type, u.real_name
ORDER BY r.region_name;