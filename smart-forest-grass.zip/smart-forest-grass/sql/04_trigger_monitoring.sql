-- sql/04_trigger_monitoring.sql
-- 环境监测业务线数据自动校验触发器（最终兼容版）
-- 作者：[你的姓名]

USE forest_grassland;

DELIMITER $$

CREATE TRIGGER tr_auto_validate_monitoring_data
BEFORE INSERT ON monitoring_data
FOR EACH ROW
BEGIN
    DECLARE v_monitor_type VARCHAR(20) DEFAULT '';

    -- 获取设备的监测类型
    SELECT d.monitor_type INTO v_monitor_type
    FROM device d
    WHERE d.device_id = NEW.device_id
    LIMIT 1;

    -- 如果设备不存在或 monitor_type 为空，则不进行校验
    IF v_monitor_type IS NOT NULL AND v_monitor_type != '' THEN

        -- 根据监测类型进行合理性校验
        IF v_monitor_type = 'temperature' THEN
            IF NEW.value_number IS NOT NULL AND (NEW.value_number < -40 OR NEW.value_number > 60) THEN
                SET NEW.data_status = 'invalid';
            END IF;

        ELSEIF v_monitor_type = 'humidity' THEN
            IF NEW.value_number IS NOT NULL AND (NEW.value_number < 0 OR NEW.value_number > 100) THEN
                SET NEW.data_status = 'invalid';
            END IF;

        ELSEIF v_monitor_type = 'image' THEN
            IF NEW.value_text IS NULL OR TRIM(NEW.value_text) = '' THEN
                SET NEW.data_status = 'invalid';
            END IF;

        -- 其他类型不校验，无需 ELSE

        END IF;

    END IF;

END$$

DELIMITER ;