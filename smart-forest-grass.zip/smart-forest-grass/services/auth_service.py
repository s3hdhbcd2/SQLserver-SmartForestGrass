# services/auth_service.py
import time
from config.db import get_db_connection

from utils.security import verify_password

login_attempts = {}  # {username: (失败次数, 最后尝试时间)}


def authenticate_user(username: str, password: str):
    current_time = time.time()

    if username in login_attempts:
        fail_count, last_time = login_attempts[username]
        if fail_count >= 5 and (current_time - last_time) < 900:
            print("❌ 账号因多次失败已被锁定，请15分钟后重试。")
            return None

    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            cursor.execute("""
                SELECT user_id, username, real_name, password_hash, role 
                FROM user 
                WHERE username = %s AND is_deleted = 0 AND is_active = 1
            """, (username,))
            row = cursor.fetchone()

            if not row:
                _record_failed_login(username)
                return None

            user_id, username, real_name, password_hash, role = (
                row['user_id'], row['username'], row['real_name'],
                row['password_hash'], row['role']
            )

            if verify_password(password, password_hash):
                login_attempts.pop(username, None)
                return {
                    "user_id": user_id,
                    "username": username,
                    "real_name": real_name,
                    "role": role
                }
            else:
                _record_failed_login(username)
                return None
    finally:
        conn.close()


def _record_failed_login(username: str):
    current_time = time.time()
    count, _ = login_attempts.get(username, (0, 0))
    login_attempts[username] = (count + 1, current_time)