# services/alert_service.py
from config.db import get_db_connection

def view_and_handle_alerts(user):
    """查看并处理属于当前护林员负责区域的未处理预警"""
    user_id = user["user_id"]
    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            # 获取该护林员负责的所有区域ID
            cursor.execute(
                "SELECT region_id FROM region WHERE ranger_id = %s AND is_deleted = 0",
                (user_id,)
            )
            regions = cursor.fetchall()
            if not regions:
                print("⚠️ 您暂无负责区域，无法接收预警。")
                return

            region_ids = [r['region_id'] for r in regions]

            # 动态构建 IN 查询（region_ids 来自可信源，风险可控）
            format_str = ','.join(['%s'] * len(region_ids))
            query = f"""
                SELECT 
                    ar.alert_id,
                    ar.content,              -- ✅ 正确字段名：content
                    ar.trigger_time,
                    ar.status,
                    ar.handle_result,
                    r.region_name
                FROM alert_record ar
                JOIN region r ON ar.region_id = r.region_id
                WHERE ar.region_id IN ({format_str}) 
                  AND ar.status IN ('unhandled', 'handling')
                ORDER BY ar.trigger_time DESC
            """
            cursor.execute(query, region_ids)
            alerts = cursor.fetchall()

            if not alerts:
                print("✅ 当前无待处理的灾害预警。")
                return

            print("\n🚨 待处理预警列表：")
            for i, a in enumerate(alerts, 1):
                status_map = {
                    'unhandled': '未处理',
                    'handling': '处理中'
                }
                print(f"{i}. {a['content']}")
                print(f"   📍 区域: {a['region_name']} | ⏰ 触发时间: {a['trigger_time']}")
                print(f"   📌 状态: {status_map.get(a['status'], a['status'])}")
                if a['handle_result']:
                    print(f"   💬 处理结果: {a['handle_result']}")
                print("-" * 50)

            choice = input("请选择要处理的预警序号（回车返回）: ").strip()
            if not choice.isdigit():
                return

            idx = int(choice) - 1
            if idx < 0 or idx >= len(alerts):
                print("❌ 无效选择。")
                return

            alert = alerts[idx]
            alert_id = alert['alert_id']
            current_status = alert['status']

            if current_status == 'unhandled':
                confirm = input("是否开始处理此预警？(y/n): ").strip().lower()
                if confirm == 'y':
                    cursor.execute("""
                        UPDATE alert_record 
                        SET status = 'handling', handler_id = %s 
                        WHERE alert_id = %s
                    """, (user_id, alert_id))
                    conn.commit()  # ✅ 提交事务
                    print("✅ 已标记为“处理中”。")
                else:
                    print("ℹ️ 已取消处理。")

            elif current_status == 'handling':
                if alert['handler_id'] != user_id:
                    print("❌ 此预警正在由其他护林员处理，您无权操作。")
                    return

                result = input("请输入处理结果（如：已现场确认无火情）: ").strip()
                if not result:
                    print("❌ 处理结果不能为空。")
                    return

                cursor.execute("""
                    UPDATE alert_record 
                    SET status = 'resolved', handle_result = %s
                    WHERE alert_id = %s
                """, (result, alert_id))
                conn.commit()  # ✅ 提交事务
                print("✅ 预警已结案！")

    except Exception as e:
        print(f"❌ 处理预警时发生错误: {e}")
    finally:
        conn.close()


def view_alert_summary_for_supervisor(user):
    """监管员查看全系统预警汇总"""
    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            cursor.execute("""
                SELECT 
                    ar.alert_id,
                    ar.content,
                    ar.trigger_time,
                    ar.status,
                    ar.region_id,
                    r.region_name,
                    rule.alert_level   -- ✅ 从 alert_rule 表获取
                FROM alert_record ar
                JOIN region r ON ar.region_id = r.region_id
                JOIN alert_rule rule ON ar.rule_id = rule.rule_id   -- ✅ 关键：JOIN 规则表
                WHERE r.is_deleted = 0
                ORDER BY ar.trigger_time DESC
            """)
            alerts = cursor.fetchall()

            if not alerts:
                print("✅ 当前无任何预警记录。")
                return

            # 统计
            unhandled = sum(1 for a in alerts if a['status'] == 'unhandled')
            handling = sum(1 for a in alerts if a['status'] == 'handling')
            resolved = sum(1 for a in alerts if a['status'] == 'resolved')

            print(f"\n📊 预警汇总统计：")
            print(f"- 未处理（unhandled）: {unhandled} 条")
            print(f"- 处理中（handling）: {handling} 条")
            print(f"- 已完成（resolved）: {resolved} 条")

            print("\n📋 详细列表：")
            for i, alert in enumerate(alerts, 1):
                time_str = alert['trigger_time'].strftime('%Y-%m-%d %H:%M')
                level = alert['alert_level']
                level_icon = '🔥' if level == 'severe' else '💧' if level == 'moderate' else '⚠️'
                print(f"[{i}] {alert['content']}")
                print(f"    🕒 {time_str} | 📍 {alert['region_name']} | "
                      f"{level_icon} {level} | 📌 {alert['status']}\n")
    except Exception as e:
        print(f"❌ 查询预警汇总时出错: {e}")
    finally:
        conn.close()