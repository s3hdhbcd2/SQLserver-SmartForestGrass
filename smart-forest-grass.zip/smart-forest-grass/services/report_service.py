# services/report_service.py
from config.db import get_db_connection
import csv
import os
from datetime import datetime


def view_resource_summary():
    """查看全区资源总量汇总"""
    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            cursor.execute("""
                SELECT 
                    resource_type,
                    species_name,
                    SUM(quantity) AS total_quantity,
                    COUNT(*) AS region_count
                FROM resource
                WHERE is_deleted = 0
                GROUP BY resource_type, species_name
                ORDER BY resource_type, total_quantity DESC
            """)
            rows = cursor.fetchall()

            if not rows:
                print("🔍 暂无资源数据。")
                return

            print("\n📊 全区资源汇总：")
            print("类型\t物种\t\t总量\t覆盖区域数")
            for r in rows:
                print(f"{r['resource_type']}\t{r['species_name']}\t{r['total_quantity']}\t{r['region_count']}")
    finally:
        conn.close()


def view_resource_by_region():
    """按区域统计资源"""
    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            cursor.execute("""
                SELECT 
                    reg.region_name,
                    res.species_name,
                    res.resource_type,
                    res.quantity
                FROM resource res
                JOIN region reg ON res.region_id = reg.region_id
                WHERE res.is_deleted = 0
                ORDER BY reg.region_name, res.species_name
            """)
            rows = cursor.fetchall()

            if not rows:
                print("🔍 暂无区域资源数据。")
                return

            print("\n🗺️ 区域资源分布：")
            current_region = ""
            for r in rows:
                if r['region_name'] != current_region:
                    print(f"\n📍 {r['region_name']}:")
                    current_region = r['region_name']
                print(f"  - {r['species_name']} ({r['resource_type']}): {r['quantity']} 株")
    finally:
        conn.close()


def export_change_logs():
    """导出资源变动日志为 CSV"""
    filename = f"resource_changes_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            cursor.execute("""
                SELECT 
                    l.change_time,
                    reg.region_name,
                    res.species_name,
                    rcr.change_type,
                    rcr.amount,
                    usr_req.real_name AS requester,
                    usr_app.real_name AS approver,
                    rcr.reason
                FROM resource_change_log l
                JOIN resource_change_request rcr ON l.resource_id = rcr.resource_id
                JOIN resource res ON l.resource_id = res.resource_id
                JOIN region reg ON res.region_id = reg.region_id
                JOIN user usr_req ON rcr.requester_id = usr_req.user_id
                LEFT JOIN user usr_app ON rcr.approver_id = usr_app.user_id
                ORDER BY l.change_time DESC
                LIMIT 1000
            """)
            rows = cursor.fetchall()

            with open(filename, 'w', newline='', encoding='utf-8-sig') as f:
                if rows:
                    writer = csv.DictWriter(f, fieldnames=rows[0].keys())
                    writer.writeheader()
                    writer.writerows(rows)
                else:
                    f.write("无变动记录\n")

            print(f"✅ 日志已导出至：{os.path.abspath(filename)}")
    finally:
        conn.close()