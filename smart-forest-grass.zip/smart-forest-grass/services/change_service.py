# services/change_service.py
from config.db import get_db_connection
from datetime import datetime

def review_resource_changes(supervisor):
    """监管员审核资源变动申请"""
    supervisor_id = supervisor["user_id"]
    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            # 查询所有 pending 状态的申请，并关联 resource 和 region 信息
            cursor.execute("""
                SELECT 
                    rcr.request_id,
                    rcr.resource_id,
                    rcr.change_type,
                    rcr.amount,
                    rcr.new_growth_stage,
                    rcr.reason,
                    rcr.create_time,
                    res.species_name,
                    res.resource_type,
                    reg.region_name,
                    usr.real_name AS requester_name
                FROM resource_change_request rcr
                JOIN resource res ON rcr.resource_id = res.resource_id
                JOIN region reg ON res.region_id = reg.region_id
                JOIN user usr ON rcr.requester_id = usr.user_id
                WHERE rcr.status = 'pending' AND rcr.is_deleted = 0
                ORDER BY rcr.create_time ASC
            """)
            requests = cursor.fetchall()

            if not requests:
                print("✅ 暂无待审核的资源变动申请。")
                return

            print("\n📄 待审核资源变动申请：")
            for i, req in enumerate(requests, 1):
                change_desc = ""
                if req['change_type'] in ('add', 'reduce'):
                    action = "新增" if req['change_type'] == 'add' else "减少"
                    change_desc = f"{action} {req['amount']} 株"
                else:  # update
                    change_desc = f"更新生长阶段为: {req['new_growth_stage']}"

                print(f"{i}. [{req['region_name']}] {req['species_name']} ({req['resource_type']})")
                print(f"   📝 变动: {change_desc}")
                print(f"   💬 原因: {req['reason']}")
                print(f"   👤 申请人: {req['requester_name']} | ⏰ 申请时间: {req['create_time']}")
                print("-" * 50)

            choice = input("请选择要处理的申请序号（回车返回）: ").strip()
            if not choice.isdigit():
                return

            idx = int(choice) - 1
            if idx < 0 or idx >= len(requests):
                print("❌ 无效选择。")
                return

            req = requests[idx]
            request_id = req['request_id']

            print("\n操作选项:")
            print("1. 批准")
            print("2. 驳回")
            action = input("请选择操作: ").strip()
            if action not in ('1', '2'):
                print("❌ 取消操作。")
                return

            if action == '1':  # 批准
                # Step 1: 更新 resource 表
                if req['change_type'] == 'add':
                    cursor.execute("""
                        UPDATE resource 
                        SET quantity = quantity + %s, update_time = NOW()
                        WHERE resource_id = %s
                    """, (req['amount'], req['resource_id']))
                elif req['change_type'] == 'reduce':
                    cursor.execute("""
                        UPDATE resource 
                        SET quantity = quantity - %s, update_time = NOW()
                        WHERE resource_id = %s
                    """, (req['amount'], req['resource_id']))
                elif req['change_type'] == 'update':
                    cursor.execute("""
                        UPDATE resource 
                        SET growth_stage = %s, update_time = NOW()
                        WHERE resource_id = %s
                    """, (req['new_growth_stage'], req['resource_id']))

                # Step 2: 插入变动日志
                cursor.execute("""
                    INSERT INTO resource_change_log (
                        change_id, resource_id, change_type, 
                        change_reason, change_time, operator_id
                    ) VALUES (
                        UUID(), %s, %s, %s, NOW(), %s
                    )
                """, (req['resource_id'], req['change_type'], req['reason'], supervisor_id))

                # Step 3: 更新申请状态
                cursor.execute("""
                    UPDATE resource_change_request 
                    SET status = 'approved', approver_id = %s, approve_time = NOW()
                    WHERE request_id = %s
                """, (supervisor_id, request_id))

                conn.commit()
                print("✅ 申请已批准，资源数据已更新！")

            elif action == '2':  # 驳回
                reject_reason = input("请输入驳回原因: ").strip()
                if not reject_reason:
                    reject_reason = "未提供具体原因"

                cursor.execute("""
                    UPDATE resource_change_request 
                    SET status = 'rejected', approver_id = %s, approve_time = NOW()
                    WHERE request_id = %s
                """, (supervisor_id, request_id))

                # 可选：记录驳回原因到日志或通知（此处简化）
                conn.commit()
                print("❌ 申请已驳回。")

    except Exception as e:
        print(f"❌ 审核过程中出错: {e}")
        conn.rollback()
    finally:
        conn.close()