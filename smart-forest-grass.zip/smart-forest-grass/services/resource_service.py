# services/resource_service.py
from config.db import get_db_connection


def update_resource_change(user):
    """
    护林员提交资源变动申请
    """
    user_id = user["user_id"]
    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            # 查询该护林员负责的所有区域及其资源（使用实际表名 `resource`）
            cursor.execute("""
                SELECT 
                    r.region_id,
                    r.region_name,
                    res.resource_id,
                    res.resource_type,
                    res.species_name,
                    res.quantity,
                    res.area,
                    res.growth_stage
                FROM region r
                JOIN resource res ON r.region_id = res.region_id
                WHERE r.ranger_id = %s AND r.is_deleted = 0 AND res.is_deleted = 0
                ORDER BY r.region_name, res.resource_type
            """, (user_id,))
            resources = cursor.fetchall()

            if not resources:
                print("⚠️ 你负责的区域暂无登记的林草资源。")
                return

            print("\n📋 可申请变动的资源列表：")
            for i, res in enumerate(resources, 1):
                qty_or_area = f"{res['quantity']}株" if res['quantity'] else f"{res['area']}亩"
                print(f"{i}. [{res['region_name']}] {res['species_name']} ({res['resource_type']}) - {qty_or_area} - {res['growth_stage']}")

            try:
                choice = int(input("\n请选择要变动的资源编号（输入0取消）: ")) - 1
                if choice == -1:
                    return
                selected = resources[choice]
            except (ValueError, IndexError):
                print("❌ 无效选择")
                return

            print("\n🔄 变动类型：1=新增数量 2=减少数量 3=更新状态")
            change_type_map = {"1": "add", "2": "reduce", "3": "update"}
            ct = input("请选择: ").strip()
            if ct not in change_type_map:
                print("❌ 无效类型")
                return

            reason = input("📝 变动原因（如：火灾损毁、补种等）: ").strip()
            if not reason:
                print("❌ 原因不能为空")
                return

            # 插入变动日志（表名正确：resource_change_log）
            from uuid import uuid4
            cursor.execute("""
                INSERT INTO resource_change_log (
                    change_id, resource_id, change_type, change_reason,
                    change_time, operator_id
                ) VALUES (%s, %s, %s, %s, NOW(), %s)
            """, (
                str(uuid4()),
                selected["resource_id"],
                change_type_map[ct],
                reason,
                user_id
            ))
            conn.commit()
            print("✅ 资源变动申请已提交，等待审核！")

    finally:
        conn.close()