# services/maintenance_service.py
from config.db import get_db_connection
from uuid import uuid4

def record_maintenance(user):
    """记录设备维护/巡检记录"""
    user_id = user["user_id"]
    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            # 先列出该护林员负责区域内的所有设备
            cursor.execute("""
                SELECT d.device_id, d.device_name, d.device_type, r.region_name
                FROM device d
                JOIN region r ON d.region_id = r.region_id
                WHERE r.ranger_id = %s AND d.is_deleted = 0
                ORDER BY r.region_name, d.device_name
            """, (user_id,))
            devices = cursor.fetchall()

            if not devices:
                print("⚠️ 您负责的区域暂无设备。")
                return

            print("\n🔧 可维护的设备列表：")
            for i, d in enumerate(devices, 1):
                print(f"{i}. [{d['device_id']}] {d['device_name']} ({d['device_type']}) - {d['region_name']}")

            choice = input("请选择设备序号: ").strip()
            if not choice.isdigit():
                print("❌ 无效输入。")
                return
            idx = int(choice) - 1
            if idx < 0 or idx >= len(devices):
                print("❌ 无效选择。")
                return

            device_id = devices[idx]['device_id']
            print("\n维护类型:")
            print("1. 巡检")
            print("2. 维修")
            print("3. 更换")
            type_choice = input("请选择: ").strip()
            type_map = {'1': '巡检', '2': '维修', '3': '更换'}
            maintenance_type = type_map.get(type_choice, '巡检')

            content = input("请输入维护内容: ").strip()
            if not content:
                print("❌ 维护内容不能为空。")
                return

            result = input("请输入维护结果（如：正常 / 已更换 / 待配件）: ").strip()
            if not result:
                result = "已完成"

            # ✅ 插入到正确的表 `maintenance_log`，使用正确字段名
            cursor.execute("""
                INSERT INTO maintenance_log (
                    log_id, device_id, maintainer_id, maintenance_time,
                    content, result
                ) VALUES (%s, %s, %s, NOW(), %s, %s)
            """, (
                str(uuid4()),      # log_id (CHAR(36))
                device_id,         # device_id
                user_id,           # maintainer_id
                content,           # content
                result             # result
            ))

            conn.commit()  # ⚠️ 别忘了提交事务！
            print("✅ 设备维护记录已保存！")
    finally:
        conn.close()

def view_maintenance_logs_for_supervisor(supervisor):
    """
    监管员查阅全系统设备维护日志
    - 显示最近50条维护记录
    - 标记超过90天未维护的设备
    """
    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            # 1. 查询最近的维护记录（最多50条）
            # 注意：字段是 log_id，不是 maintenance_id！
            cursor.execute("""
                SELECT 
                    ml.log_id,               -- ✅ 正确字段
                    d.device_name,
                    d.device_type,
                    r.region_name,
                    ml.maintenance_time,
                    ml.content,
                    ml.result,
                    u.real_name AS maintainer
                FROM maintenance_log ml
                JOIN device d ON ml.device_id = d.device_id
                JOIN region r ON d.region_id = r.region_id
                JOIN user u ON ml.maintainer_id = u.user_id
                WHERE d.is_deleted = 0 
                  AND r.is_deleted = 0
                ORDER BY ml.maintenance_time DESC
                LIMIT 50
            """)
            logs = cursor.fetchall()

            print("\n🔧 最近维护记录（最新50条）：")
            if logs:
                for log in logs:
                    time_str = log['maintenance_time'].strftime('%Y-%m-%d %H:%M')
                    print(f"[{log['region_name']}] {log['device_name']} ({log['device_type']})")
                    print(f"  ⏰ {time_str} | 👤 {log['maintainer']}")
                    print(f"  📝 内容: {log['content']}")
                    print(f"  ✅ 结果: {log['result']}\n")
            else:
                print("⚠️ 暂无维护记录。")

            # 2. 检查超期未维护设备（>90天）
            # 注意：maintenance_log 没有 is_deleted，所以不加 ml.is_deleted=0
            cursor.execute("""
                SELECT 
                    d.device_name,
                    d.device_type,
                    r.region_name,
                    MAX(ml.maintenance_time) AS last_maint
                FROM device d
                JOIN region r ON d.region_id = r.region_id
                LEFT JOIN maintenance_log ml ON d.device_id = ml.device_id
                WHERE d.is_deleted = 0 
                  AND r.is_deleted = 0
                GROUP BY d.device_id, d.device_name, d.device_type, r.region_name
                HAVING last_maint IS NULL OR last_maint < DATE_SUB(NOW(), INTERVAL 90 DAY)
                ORDER BY last_maint ASC
            """)
            stale_devices = cursor.fetchall()

            if stale_devices:
                print(f"\n🚨 超90天未维护的设备（共{len(stale_devices)}台）：")
                for dev in stale_devices:
                    if dev['last_maint']:
                        last_str = dev['last_maint'].strftime('%Y-%m-%d')
                    else:
                        last_str = '从未维护'
                    print(f"  [{dev['region_name']}] {dev['device_name']} ({dev['device_type']}) → 最后维护: {last_str}")
            else:
                print("\n✅ 所有设备均在90天内完成过维护。")

    except Exception as e:
        print(f"❌ 查询维护日志时出错: {e}")
    finally:
        conn.close()