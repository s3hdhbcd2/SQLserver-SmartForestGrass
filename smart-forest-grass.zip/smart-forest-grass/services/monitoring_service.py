# services/monitoring_service.py
from config.db import get_db_connection
from datetime import datetime, timedelta

def get_regions_by_ranger(ranger_id: str):
    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            cursor.execute("""
                SELECT region_id, region_name, region_type 
                FROM region 
                WHERE ranger_id = %s AND is_deleted = 0
            """, (ranger_id,))
            return cursor.fetchall()
    finally:
        conn.close()

def get_monitoring_data_by_region(region_id: str, hours: int = 24):
    since = datetime.now() - timedelta(hours=hours)
    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            cursor.execute("""
                SELECT d.device_name, d.monitor_type, m.collect_time, 
                       m.value_number, m.value_text, m.data_status
                FROM monitoring_data m
                JOIN device d ON m.device_id = d.device_id
                WHERE d.region_id = %s 
                  AND m.collect_time >= %s
                  AND m.data_status = 'valid'
                  AND d.is_deleted = 0
                ORDER BY m.collect_time DESC
                LIMIT 100
            """, (region_id, since))
            return cursor.fetchall()
    finally:
        conn.close()