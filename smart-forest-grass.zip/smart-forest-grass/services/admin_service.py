# services/admin_service.py
from config.db import get_db_connection


def assign_ranger_to_region(ranger_user_id: str, region_id: str):
    conn = get_db_connection()
    try:
        with conn.cursor() as cursor:
            cursor.execute("SELECT role FROM user WHERE user_id = %s AND is_deleted = 0", (ranger_user_id,))
            user = cursor.fetchone()
            if not user or user['role'] != 'ranger':
                return False, "❌ 指定用户不是护林员或不存在"

            cursor.execute("SELECT region_id FROM region WHERE region_id = %s AND is_deleted = 0", (region_id,))
            if not cursor.fetchone():
                return False, "❌ 区域不存在"

            cursor.execute("""
                UPDATE region SET ranger_id = %s WHERE region_id = %s
            """, (ranger_user_id, region_id))
            conn.commit()
            return True, "✅ 区域分配成功"
    except Exception as e:
        conn.rollback()
        return False, f"❌ 操作失败: {str(e)}"
    finally:
        conn.close()

# services/admin_service.py（追加以下函数）

from config.db import get_db_connection
import uuid
from datetime import datetime


def manage_devices():
    """系统管理员：设备档案管理"""
    conn = get_db_connection()
    try:
        while True:
            print("\n📡 设备档案管理")
            print("1. 查看所有设备")
            print("2. 新增设备")
            print("3. 编辑设备")
            print("4. 删除设备（软删除）")
            print("0. 返回上级")
            choice = input("请选择: ").strip()

            if choice == "0":
                break
            elif choice == "1":
                _list_devices(conn)
            elif choice == "2":
                _create_device(conn)
            elif choice == "3":
                _edit_device(conn)
            elif choice == "4":
                _delete_device(conn)
            else:
                print("❓ 无效选项")
    except Exception as e:
        print(f"❌ 系统错误: {e}")
        conn.rollback()
    finally:
        conn.close()


def _list_devices(conn):
    with conn.cursor() as cursor:
        cursor.execute("""
            SELECT 
                d.device_id,
                d.device_name,
                d.device_type,
                d.monitor_type,
                d.model,
                r.region_name,
                u.real_name AS installer_name,
                d.install_time,
                d.is_deleted
            FROM device d
            LEFT JOIN region r ON d.region_id = r.region_id
            LEFT JOIN user u ON d.installer_id = u.user_id
            ORDER BY d.create_time DESC
        """)
        devices = cursor.fetchall()

        if not devices:
            print("📭 暂无设备记录")
            return

        print(f"\n{'ID':<38} {'名称':<15} {'类型':<10} {'监测项':<12} {'区域':<15} {'安装人'}")
        print("-" * 95)
        for dev in devices:
            status = " (已删除)" if dev['is_deleted'] else ""
            print(
                f"{dev['device_id'][:8]}... "
                f"{dev['device_name']:<15} "
                f"{dev['device_type']:<10} "
                f"{dev['monitor_type']:<12} "
                f"{dev['region_name'] or '—':<15} "
                f"{dev['installer_name'] or '—'}{status}"
            )


def _select_region(conn):
    """辅助函数：选择区域"""
    cursor = conn.cursor()
    cursor.execute("SELECT region_id, region_name FROM region WHERE is_deleted = 0")
    regions = cursor.fetchall()
    if not regions:
        print("❌ 无可用区域，请先创建区域！")
        return None

    print("\n🗺️ 可选区域:")
    for i, reg in enumerate(regions, 1):
        print(f"{i}. {reg['region_name']}")
    try:
        idx = int(input("请选择区域序号: ")) - 1
        if 0 <= idx < len(regions):
            return regions[idx]['region_id']
        else:
            print("❌ 无效选择")
            return None
    except ValueError:
        print("❌ 输入错误")
        return None


def _select_installer(conn):
    """辅助函数：选择安装人（仅限 ranger / admin / data_admin）"""
    cursor = conn.cursor()
    cursor.execute("""
        SELECT user_id, real_name, username 
        FROM user 
        WHERE role IN ('ranger', 'admin', 'data_admin') 
          AND is_deleted = 0 
          AND is_active = 1
        ORDER BY real_name
    """)
    users = cursor.fetchall()
    if not users:
        print("❌ 无可用安装人员")
        return None

    print("\n👷 可选安装人:")
    for i, u in enumerate(users, 1):
        print(f"{i}. {u['real_name']} ({u['username']})")
    try:
        idx = int(input("请选择安装人序号: ")) - 1
        if 0 <= idx < len(users):
            return users[idx]['user_id']
        else:
            print("❌ 无效选择")
            return None
    except ValueError:
        print("❌ 输入错误")
        return None


def _create_device(conn):
    print("\n➕ 新增设备")
    device_name = input("设备名称: ").strip()
    if not device_name:
        print("❌ 名称不能为空")
        return

    # 设备类型
    device_types = ['sensor', 'camera', 'alert_device']
    print("\n设备类型:")
    for i, t in enumerate(device_types, 1):
        print(f"{i}. {t}")
    try:
        dt_idx = int(input("请选择设备类型序号: ")) - 1
        device_type = device_types[dt_idx]
    except (ValueError, IndexError):
        print("❌ 无效选择")
        return

    # 监测类型（根据设备类型动态调整，此处简化）
    monitor_types = ['temperature', 'humidity', 'image', 'other']
    print("\n监测类型:")
    for i, m in enumerate(monitor_types, 1):
        print(f"{i}. {m}")
    try:
        mt_idx = int(input("请选择监测类型序号: ")) - 1
        monitor_type = monitor_types[mt_idx]
    except (ValueError, IndexError):
        print("❌ 无效选择")
        return

    model = input("型号（可选）: ").strip() or None
    protocol = input("通信协议（如 MQTT/HTTP）: ").strip() or None
    warranty = input("保修月数（数字，可选）: ").strip()
    warranty = int(warranty) if warranty.isdigit() else None

    # 选择区域和安装人
    region_id = _select_region(conn)
    if not region_id:
        return
    installer_id = _select_installer(conn)
    if not installer_id:
        return

    install_time_str = input("安装时间（格式 YYYY-MM-DD HH:MM，回车跳过）: ").strip()
    install_time = None
    if install_time_str:
        try:
            install_time = datetime.strptime(install_time_str, "%Y-%m-%d %H:%M")
        except ValueError:
            print("⚠️ 时间格式错误，将不记录安装时间")

    purchase_time_str = input("采购日期（YYYY-MM-DD，可选）: ").strip()
    purchase_time = None
    if purchase_time_str:
        try:
            purchase_time = datetime.strptime(purchase_time_str, "%Y-%m-%d").date()
        except ValueError:
            print("⚠️ 日期格式错误")

    # 插入数据库
    device_id = str(uuid.uuid4())
    with conn.cursor() as cursor:
        cursor.execute("""
            INSERT INTO device (
                device_id, device_name, device_type, monitor_type, model,
                region_id, installer_id, install_time, protocol,
                purchase_time, warranty_months, create_time
            ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, NOW())
        """, (
            device_id, device_name, device_type, monitor_type, model,
            region_id, installer_id, install_time, protocol,
            purchase_time, warranty
        ))
        conn.commit()
        print(f"✅ 设备【{device_name}】创建成功！ID: {device_id[:8]}...")


def _edit_device(conn):
    print("\n✏️ 编辑设备")
    device_id_input = input("请输入设备ID（或部分ID）: ").strip()
    if not device_id_input:
        print("❌ ID 不能为空")
        return

    with conn.cursor() as cursor:
        cursor.execute("""
            SELECT * FROM device WHERE device_id LIKE %s AND is_deleted = 0
        """, (f"{device_id_input}%",))
        candidates = cursor.fetchall()

        if not candidates:
            print("❌ 未找到匹配的设备")
            return
        elif len(candidates) > 1:
            print("🔍 找到多个设备，请输入完整ID:")
            for dev in candidates:
                print(f"  - {dev['device_id']} | {dev['device_name']}")
            return

        dev = candidates[0]
        print(f"\n当前设备: 【{dev['device_name']}】({dev['device_id']})")

        # 允许修改的字段
        new_name = input(f"新名称（回车保持「{dev['device_name']}」）: ").strip() or dev['device_name']
        new_model = input(f"新型号（当前: {dev['model'] or '—'}）: ").strip() or dev['model']

        # 修改区域？
        change_region = input("是否修改所属区域？(y/n): ").strip().lower() == 'y'
        region_id = dev['region_id']
        if change_region:
            region_id = _select_region(conn)
            if not region_id:
                return

        # 修改安装人？
        change_installer = input("是否修改安装人？(y/n): ").strip().lower() == 'y'
        installer_id = dev['installer_id']
        if change_installer:
            installer_id = _select_installer(conn)
            if not installer_id:
                return

        # 更新
        cursor.execute("""
            UPDATE device SET
                device_name = %s,
                model = %s,
                region_id = %s,
                installer_id = %s
            WHERE device_id = %s
        """, (new_name, new_model, region_id, installer_id, dev['device_id']))
        conn.commit()
        print("✅ 设备信息已更新！")


def _delete_device(conn):
    print("\n🗑️ 软删除设备")
    device_id = input("请输入完整设备ID: ").strip()
    if not device_id:
        return

    with conn.cursor() as cursor:
        cursor.execute("SELECT device_name FROM device WHERE device_id = %s AND is_deleted = 0", (device_id,))
        dev = cursor.fetchone()
        if not dev:
            print("❌ 设备不存在或已被删除")
            return

        confirm = input(f"确认删除设备【{dev['device_name']}】？(y/n): ").strip().lower()
        if confirm != 'y':
            return

        cursor.execute("UPDATE device SET is_deleted = 1 WHERE device_id = %s", (device_id,))
        conn.commit()
        print("✅ 设备已软删除（数据保留）")

# ==============================
# 用户账号管理（完整版）
# ==============================

from werkzeug.security import generate_password_hash


def manage_users():
    """系统管理员：用户账号管理"""
    conn = get_db_connection()
    try:
        while True:
            print("\n👥 用户账号管理")
            print("1. 查看所有用户")
            print("2. 新增用户")
            print("3. 启用/禁用用户")
            print("0. 返回上级")
            choice = input("请选择: ").strip()

            if choice == "0":
                break
            elif choice == "1":
                _list_all_users(conn)
            elif choice == "2":
                _create_new_user(conn)
            elif choice == "3":
                _toggle_user_active(conn)
            else:
                print("❓ 无效选项")
    finally:
        conn.close()


def _list_all_users(conn):
    with conn.cursor() as cursor:
        cursor.execute("""
            SELECT user_id, username, real_name, role, is_active, is_deleted
            FROM user
            ORDER BY create_time DESC
        """)
        users = cursor.fetchall()
        if not users:
            print("📭 暂无用户")
            return
        print(f"\n{'ID':<38} {'用户名':<15} {'姓名':<10} {'角色':<12} {'状态'}")
        print("-" * 70)
        for u in users:
            if u['is_deleted']:
                status = "❌ 已删除"
            elif u['is_active']:
                status = "🟢 启用"
            else:
                status = "🔴 禁用"
            print(f"{u['user_id'][:8]}... {u['username']:<15} {u['real_name']:<10} {u['role']:<12} {status}")


def _create_new_user(conn):
    print("\n➕ 新增用户")
    username = input("用户名（唯一）: ").strip()
    if not username:
        print("❌ 用户名不能为空")
        return
    real_name = input("真实姓名: ").strip()
    if not real_name:
        print("❌ 姓名不能为空")
        return

    roles = ['admin', 'data_admin', 'supervisor', 'ranger', 'public']
    print("\n可选角色:")
    for i, r in enumerate(roles, 1):
        print(f"{i}. {r}")
    try:
        idx = int(input("请选择角色序号: ")) - 1
        role = roles[idx]
    except (ValueError, IndexError):
        print("❌ 无效选择")
        return

    password = input("密码（默认 123456）: ").strip() or "123456"
    pwd_hash = generate_password_hash(password)

    with conn.cursor() as cursor:
        # 检查用户名是否重复
        cursor.execute("SELECT 1 FROM user WHERE username = %s AND is_deleted = 0", (username,))
        if cursor.fetchone():
            print("❌ 用户名已存在！")
            return

        user_id = str(uuid.uuid4())
        cursor.execute("""
            INSERT INTO user (user_id, username, password_hash, real_name, role, is_active, create_time)
            VALUES (%s, %s, %s, %s, %s, 1, NOW())
        """, (user_id, username, pwd_hash, real_name, role))
        conn.commit()
        print(f"✅ 用户【{real_name}】({username}) 创建成功！")


def _toggle_user_active(conn):
    print("\n🔄 启用/禁用用户")
    username = input("请输入用户名: ").strip()
    if not username:
        print("❌ 用户名不能为空")
        return

    with conn.cursor() as cursor:
        cursor.execute("""
            SELECT user_id, username, real_name, is_active, is_deleted
            FROM user WHERE username = %s
        """, (username,))
        user = cursor.fetchone()
        if not user:
            print("❌ 用户不存在")
            return
        if user['is_deleted']:
            print("❌ 该用户已被删除，无法操作")
            return

        current = "启用" if user['is_active'] else "禁用"
        new_status = 0 if user['is_active'] else 1
        action = "禁用" if user['is_active'] else "启用"

        confirm = input(f"当前状态：{current}，确认要{action}用户【{user['real_name']}】吗？(y/n): ").strip().lower()
        if confirm != 'y':
            return

        cursor.execute("UPDATE user SET is_active = %s WHERE user_id = %s", (new_status, user['user_id']))
        conn.commit()
        print(f"✅ 用户【{user['real_name']}】已{action}！")

# ==============================
# 区域分配管理（交互式）
# ==============================

def manage_region_assignments():
    """系统管理员：区域分配管理（绑定护林员到区域）"""
    conn = get_db_connection()
    try:
        while True:
            print("\n🗺️ 区域分配管理")
            print("1. 查看所有区域及负责人")
            print("2. 分配护林员到区域")
            print("0. 返回上级")
            choice = input("请选择: ").strip()

            if choice == "0":
                break
            elif choice == "1":
                _list_regions_with_rangers(conn)
            elif choice == "2":
                _assign_ranger_interactive(conn)
            else:
                print("❓ 无效选项")
    finally:
        conn.close()


def _list_regions_with_rangers(conn):
    with conn.cursor() as cursor:
        cursor.execute("""
            SELECT 
                r.region_id,
                r.region_name,
                r.region_type,
                u.real_name AS ranger_name,
                r.is_deleted
            FROM region r
            LEFT JOIN user u ON r.ranger_id = u.user_id AND u.is_deleted = 0
            ORDER BY r.create_time DESC
        """)
        regions = cursor.fetchall()
        if not regions:
            print("📭 暂无区域记录")
            return
        print(f"\n{'区域ID':<38} {'名称':<15} {'类型':<10} {'负责人'}")
        print("-" * 60)
        for reg in regions:
            status = " (已删除)" if reg['is_deleted'] else ""
            ranger = reg['ranger_name'] or "—"
            print(f"{reg['region_id'][:8]}... {reg['region_name']:<15} {reg['region_type']:<10} {ranger}{status}")


def _assign_ranger_interactive(conn):
    print("\n➕ 分配护林员到区域")

    # 选择护林员（仅 active & not deleted）
    with conn.cursor() as cursor:
        cursor.execute("""
            SELECT user_id, real_name, username 
            FROM user 
            WHERE role = 'ranger' AND is_deleted = 0 AND is_active = 1
            ORDER BY real_name
        """)
        rangers = cursor.fetchall()
    if not rangers:
        print("❌ 无可用护林员（需角色为 ranger、已启用、未删除）")
        return

    print("\n👷 可选护林员:")
    for i, r in enumerate(rangers, 1):
        print(f"{i}. {r['real_name']} ({r['username']})")
    try:
        idx = int(input("请选择护林员序号: ")) - 1
        if not (0 <= idx < len(rangers)):
            print("❌ 无效选择")
            return
        ranger_id = rangers[idx]['user_id']
    except ValueError:
        print("❌ 输入错误")
        return

    # 选择区域（未删除）
    with conn.cursor() as cursor:
        cursor.execute("SELECT region_id, region_name FROM region WHERE is_deleted = 0")
        regions = cursor.fetchall()
    if not regions:
        print("❌ 无可用区域")
        return

    print("\n🌍 可选区域:")
    for i, reg in enumerate(regions, 1):
        print(f"{i}. {reg['region_name']}")
    try:
        idx = int(input("请选择区域序号: ")) - 1
        if not (0 <= idx < len(regions)):
            print("❌ 无效选择")
            return
        region_id = regions[idx]['region_id']
    except ValueError:
        print("❌ 输入错误")
        return

    # 调用你已有的函数
    success, msg = assign_ranger_to_region(ranger_id, region_id)
    print(msg)