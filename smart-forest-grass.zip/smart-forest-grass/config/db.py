# config/db.py
import pymysql
from pymysql.cursors import DictCursor

def get_db_connection():
    return pymysql.connect(
        host='localhost',
        user='root',          # 根据你的环境修改
        password='lwq136336',    # 修改为你的密码
        database='forest_grassland',  # 替换为你的数据库名
        charset='utf8mb4',
        cursorclass=DictCursor,
        autocommit=False
    )
